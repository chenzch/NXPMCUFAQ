/*==================================================================================================
*   Project              : RTD AUTOSAR 4.7
*   Platform             : CORTEXM
*   Peripheral           : S32K3XX
*   Dependencies         : none
*
*   Autosar Version      : 4.7.0
*   Autosar Revision     : ASR_REL_4_7_REV_0000
*   Autosar Conf.Variant :
*   SW Version           : 3.0.0
*   Build Version        : S32K3_RTD_3_0_0_D2303_ASR_REL_4_7_REV_0000_20230331
*
*   Copyright 2020 - 2023 NXP Semiconductors
*
*   NXP Confidential. This software is owned or controlled by NXP and may only be
*   used strictly in accordance with the applicable license terms. By expressly
*   accepting such terms or by downloading, installing, activating and/or otherwise
*   using the software, you are agreeing that you have read, and that you agree to
*   comply with and are bound by, such license terms. If you do not agree to be
*   bound by the applicable license terms, then you may not retain, install,
*   activate or otherwise use the software.
==================================================================================================*/

/**
*   @file main.c
*
*   @addtogroup main_module main module documentation
*   @{
*/

/* Including necessary configuration files. */
#include "Mcal.h"

volatile int exit_code = 0;
/* User includes */

#include "S32K324_MC_ME.h"

void MultiCore_EnableCore1(uint32_t CORE1_ADDR)
{
	/*set the startup address */
	IP_MC_ME->PRTN0_CORE1_ADDR = CORE1_ADDR; /* &VTABLE_C1;*/
	/* enable the application processor clock */
	IP_MC_ME->PRTN0_CORE1_PCONF = MC_ME_PRTN0_CORE1_PCONF_CCE_MASK;

	/* trigger the update */
	IP_MC_ME->PRTN0_CORE1_PUPD = MC_ME_PRTN0_CORE1_PUPD_CCUPD_MASK;
	/* write the key sequence */
	IP_MC_ME->CTL_KEY = 0x5AF0;
	IP_MC_ME->CTL_KEY = 0xA50F;

	while(0==(MC_ME_PRTN0_CORE1_STAT_CCS_MASK & IP_MC_ME->PRTN0_CORE1_STAT));
}


static void JumpToUserApplication(uint32_t BASE_ADDR)
{
	/* Check if Entry address is erased and return if erased */
	uint32_t* pACCData = (uint32_t*)BASE_ADDR;
	uint32_t userSP = pACCData[0];
	register uint32_t userEntry = pACCData[1];

    if(userSP == 0xFFFFFFFF){
        return;
    }

    /* Set up stack pointer */
    __asm (
    	"cpsid i \t\n"
		"msr msp, %[inputSP] \t\n"
		"msr psp, %[inputSP] \t\n"
    	:
    	: [inputSP] "r" (userSP)
    );

    /* Jump to application PC (r1) */
    __asm (
		"mov pc, %[inputEntry] \t\n"
    	:
    	: [inputEntry] "r" (userEntry)
    );
}

/*!
  \brief The main function for the project.
  \details The startup initialization sequence is the following:
 * - startup asm routine
 * - main()
*/
int main(void)
{
    /* Write your code here */
	extern uint32_t * __APP0_VTOR;
	extern uint32_t * __APP1_VTOR;

	MultiCore_EnableCore1((uint32)&__APP1_VTOR);
	JumpToUserApplication((uint32)&__APP0_VTOR);

    for(;;)
    {
        if(exit_code != 0)
        {
            break;
        }
    }
    return exit_code;
}

/** @} */
